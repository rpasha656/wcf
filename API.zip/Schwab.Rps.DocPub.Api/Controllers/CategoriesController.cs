﻿
namespace Schwab.Rps.DocPub.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using DocPubServiceReference;
    using System.Web.Http;
    using Newtonsoft.Json;
    using Microsoft.Practices.ServiceLocation;
    using Microsoft.Practices.Unity;
    using System.Net.Http;
    using System.Net;
    using NLog; 

    /// <summary>
    /// Categories Controller
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.Controller" />   
    [RoutePrefix("api/Categories")]
    public class CategoriesController : ApiController
    {
        /// <summary>
        /// The logger
        /// </summary>
        //private readonly ILogger _logger;


        /// <summary>
        /// The memory cache.
        /// </summary>
        //private readonly IMemoryCache _memoryCache;

        /// <summary>
        /// Initializes a new instance of the <see cref="CategoriesController"/> class.
        /// </summary>
        /// <param name="fileMetadata">
        /// The file metadata.
        /// </param>
        /// <param name="logger">
        /// The logger.
        /// </param>
        /// <param name="memCache">
        /// The mem Cache.
        /// </param>
        //public CategoriesController(IFileMetadata fileMetadata, ILoggingService logger, IMemoryCache memCache)
        //{
        //    this.FileMetadata = fileMetadata;
        //    this._logger = logger;
        //    this._memoryCache = memCache;
        //}

        /// <summary>
        /// The Category Operation Name.
        /// </summary>
        public enum CategoryOperationName
        {
            /// <summary>
            /// Added
            /// </summary>
            CategoryAdded = 200,

            /// <summary>
            /// Updated
            /// </summary>
            CategoryUpdated = 201,

            /// <summary>
            /// Deleted
            /// </summary>
            CategoryDeleted = 202
        }

        /// <summary>
        /// The Sub Category Operation Name.
        /// </summary>
        public enum SubCategoryOperationName
        {
            /// <summary>
            /// Added
            /// </summary>
            SubCategoryAdded= 300,

            /// <summary>
            /// Updated
            /// </summary>
            SubCategoryUpdated = 301,

            /// <summary>
            /// Deleted
            /// </summary>
            SubCategoryDeleted = 302
        }

        /// <summary>
        /// Gets or sets the add file metadata.
        /// </summary>
        /// <value>
        /// The add file metadata.
        /// </value>
        public IFileMetadata FileMetadata { get; set; }

        /// <summary>
        /// Gets all Categories and SubCategories.
        /// </summary>    
        /// <returns>Categories and SubCategories in Json format</returns>
        //[HttpGet]
        [Route("AllCategories")]
        public IHttpActionResult GetAllCategories()
        {
            try
            {
                IFileMetadata fileMetadata = new FileMetadataClient();               

                //_logger.Info("Calling the FileMetadata method to get all Categories and SubCategories");                

                var getCategories = fileMetadata.GetCategoriesAsync();
                ////var getCategories = this.SetGetCategoriesMemoryCache();
                var categories = getCategories.Result;

                if (!categories.Any())
                {
                    return BadRequest();                   
                }

                //_logger.Info("Categories and SubCategories records have been fetched");
                return Ok(categories);           
               
            }
            catch (Exception ex)
            {
                //_logger.Error(ex.Message);
                return StatusCode(HttpStatusCode.InternalServerError);
            }    
        }

        [HttpPost]
        [Route("AddUpdateCategories")]
        public IHttpActionResult PostAddUpdateCategories([FromBody] CategoryDataContract categoryDataContract)
        {
            IFileMetadata fileMetadata = new FileMetadataClient();
            //this._logger.Info("Calling the Category method");

            if (categoryDataContract == null)
            {
                //this._logger.Error("Empty CategoryDataContract object");
                return this.BadRequest();
            }

            try
            {
                var result = fileMetadata.AddUpdateCategoryAsync(categoryDataContract).Result;
                if (result <= 0)
                {
                    //this._logger.Info("Record has not been added into category");
                    return this.BadRequest();
                }

                AuditDataContract auditDataContract = new AuditDataContract();
                Audit(auditDataContract, categoryDataContract, result);

                //this._logger.Info("Record has been added into Category");
                return this.Ok(result);

            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return this.StatusCode(HttpStatusCode.InternalServerError);
            }
        }

        public int Audit(AuditDataContract auditDataContract, CategoryDataContract categoryData, int fileMetadataId)
        {
            int auditResult;
            //this._logger.Info("Calling the Audit method");

            try
            {               
                auditDataContract.UserId = "UserId1";
                if (categoryData.Id > 0)
                {                    
                    auditDataContract.Description = "Category Id:" + categoryData.Id + " document has been updated.";
                    auditDataContract.OperationId = Convert.ToInt16(CategoryOperationName.CategoryUpdated);
                    auditResult = this.FileMetadata.AddAuditInformationAsync(auditDataContract).Result;
                    if (auditResult <= 0)
                    {
                        //this._logger.Info("Record has not been updated into Audit");
                        return 0;
                    }
                    //this._logger.Info("Record has been updated into Audit");
                }
                else
                {                   
                    auditDataContract.Description = "Category Id:" + fileMetadataId + " document has been added.";
                    auditDataContract.OperationId = Convert.ToInt16(CategoryOperationName.CategoryAdded);
                    auditResult = this.FileMetadata.AddAuditInformationAsync(auditDataContract).Result;
                    if (auditResult <= 0)
                    {
                        //this._logger.Info("Record has not been added into Audit");
                        return 0;
                    }
                    //this._logger.Info("Record has been added into Audit");
                }

                return auditResult;
            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return 0;
            }
        }

        /// <summary>
        /// The set get categories memory cache.
        /// </summary>
        /// <returns>
        /// The <see cref="Task"/>.
        /// </returns>
        //private Task<CategoryDataContract[]> SetGetCategoriesMemoryCache()
        //{           
        //    string key = "CategoriesMemoryKey-Cache";
        //    Task<CategoryDataContract[]> getCategories;

        //    if (this._memoryCache != null)
        //    {                
        //        if (!this._memoryCache.TryGetValue(key, out getCategories))
        //        {
        //            getCategories = this.FileMetadata.GetCategoriesAsync();
        //            this._memoryCache.Set(key, getCategories, new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(1)));
        //            this._logger.LogInformation("Categories and SubCategories records have been added in Cache");
        //        }
        //        else
        //        {
        //            getCategories = this._memoryCache.Get(key) as Task<CategoryDataContract[]>;
        //            this._logger.LogInformation("Categories and SubCategories records have been retrieved from in Cache");
        //        }
        //    }
        //    else
        //    {
        //        getCategories = this.FileMetadata.GetCategoriesAsync();
        //    }
        //    return getCategories;
        //}
    }
}
