﻿
namespace Schwab.Rps.DocPub.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using DocPubServiceReference;
    using System.Web.Http;
    using Newtonsoft.Json;
    using Microsoft.Practices.ServiceLocation;
    using Microsoft.Practices.Unity;
    using System.Net.Http;
    using System.Net;
    using NLog;

    /// <summary>
    /// FileMetadata controller
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.Controller" />
    [RoutePrefix("api/files")]
    public class FilesController : ApiController
    {
        /// <summary>
        /// The logger
        /// </summary>
        //private readonly ILogger _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="FilesController"/> class.
        /// </summary>
        /// <param name="fileMetadata">The file metadata.</param>
        /// <param name="logger">The logger.</param>
        //public FilesController(IFileMetadata fileMetadata, ILogger<FilesController> logger)
        //{
        //    this.FileMetadata = fileMetadata;
        //    this._logger = logger;
        //}       

        /// <summary>
        /// The status.
        /// </summary>
        public enum Status
        {
            /// <summary>
            /// The uploaded.
            /// </summary>
            Uploaded = 1,

            /// <summary>
            /// The review.
            /// </summary>
            Review = 2,

            /// <summary>
            /// The published.
            /// </summary>
            Published = 3
        }

        /// <summary>
        /// The Operation Name.
        /// </summary>
        public enum OperationName
        {
            /// <summary>
            /// Added
            /// </summary>
            DocumentUploaded = 100,

            /// <summary>
            /// Updated
            /// </summary>
            DocumentUpdated = 101,

            /// <summary>
            /// Deleted
            /// </summary>
            DocumentDeleted = 102
        }

        /// <summary>
        /// Gets or sets the add file metadata.
        /// </summary>
        /// <value>
        /// The add file metadata.
        /// </value>
        public IFileMetadata FileMetadata { get; set; }

        /// <summary>
        /// Posts the specified file metadata data contract.
        /// </summary>
        /// <param name="fileMetadataDataContract">The file metadata data contract.</param>
        /// <returns>FileMeta Id</returns>
        [HttpPost]
        [Route("AddFileMetadata")]
        public IHttpActionResult PostAddFileMetadata([FromBody] FileMetadataDataContract fileMetadataDataContract)
        {
            IFileMetadata fileMetadata = new FileMetadataClient();
            //this._logger.Info("Calling the FileMetadata method");

            if (fileMetadataDataContract == null)
            {
                //this._logger.Error("Empty FileMetaDataContract object");
                return this.BadRequest();
            }

            try
            {
                // Need to call SPOS for adding document, use the GUID to add document
                // Once the document is added in SPOS, we will need to save SPOS GUID into our database
                // fileMetadataDataContract.SposId = 1;
                fileMetadataDataContract.StatusId = Convert.ToInt16(Status.Uploaded);

                var result = fileMetadata.AddFileMetadataAsync(fileMetadataDataContract).Result;
                if (result <= 0)
                {
                    //this._logger.Info("Record has not been added into FileMetadata");
                    return this.BadRequest();
                }

                AuditDataContract auditDataContract = new AuditDataContract();
                Audit(auditDataContract, fileMetadataDataContract, result);

                //this._logger.Info("Record has been added into FileMetadata");
                return this.Ok(result);

            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return this.StatusCode(HttpStatusCode.InternalServerError);
            }
        }

        public int Audit(AuditDataContract auditDataContract, FileMetadataDataContract fileMetadata, int fileMetadataId)
        {
            int auditResult;
            //this._logger.Info("Calling the Audit method");

            try
            {
                auditDataContract.PlanId = fileMetadata.PlanName;
                auditDataContract.UserId = "UserId1";
                if (fileMetadata.Id > 0)
                {
                    auditDataContract.FileMetadataId = fileMetadata.Id;
                    auditDataContract.Description = "File Metadata Id:" + fileMetadata.Id + " document has been updated.";
                    auditDataContract.OperationId = Convert.ToInt16(OperationName.DocumentUpdated);
                    auditResult = this.FileMetadata.AddAuditInformationAsync(auditDataContract).Result;
                    if (auditResult <= 0)
                    {
                        //this._logger.Info("Record has not been updated into Audit");
                        return 0;
                    }
                    //this._logger.Info("Record has been updated into Audit");
                }
                else
                {
                    auditDataContract.FileMetadataId = fileMetadataId;
                    auditDataContract.Description = "File Metadata Id:" + fileMetadataId + " document has been added.";
                    auditDataContract.OperationId = Convert.ToInt16(OperationName.DocumentUploaded);
                    auditResult = this.FileMetadata.AddAuditInformationAsync(auditDataContract).Result;
                    if (auditResult <= 0)
                    {
                        //this._logger.Info("Record has not been added into Audit");
                        return 0;
                    }
                    //this._logger.Info("Record has been added into Audit");
                }

                return auditResult;
            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return 0;
            }
        }
    }
}