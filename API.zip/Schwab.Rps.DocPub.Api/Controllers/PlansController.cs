﻿
namespace Schwab.Rps.DocPub.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using DocPubServiceReference;
    using System.Web.Http;
    using NLog;
    using Newtonsoft.Json;
    using Microsoft.Practices.ServiceLocation;
    using Microsoft.Practices.Unity;
    using System.Net.Http;
    using System.Net;

    /// <summary>
    /// Categories Controller
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.Controller" />   
    [RoutePrefix("api/Plans")]
    public class PlansController : ApiController
    {
        ///// <summary>
        ///// The logger
        ///// </summary>
        //private readonly ILogger _logger;

        ///// <summary>
        ///// The memory cache.
        ///// </summary>
        //private readonly IMemoryCache _memoryCache;

        ///// <summary>
        ///// Initializes a new instance of the <see cref="PlansController"/> class.
        ///// </summary>
        ///// <param name="fileMetadata">The file metadata.</param>
        ///// <param name="logger">The logger.</param>
        ///// <param name="memCache">The mem Cache.</param>
        //public PlansController(IFileMetadata fileMetadata, ILogger<PlansController> logger, IMemoryCache memCache)
        //{
        //    this.FileMetadata = fileMetadata;
        //    this._logger = logger;
        //    this._memoryCache = memCache;
        //}
        
        /// <summary>
        /// Gets or sets the add file metadata.
        /// </summary>
        /// <value>
        /// The add file metadata.
        /// </value>
        //public IFileMetadata FileMetadata { get; set; }

        IFileMetadata fileMetadata = new FileMetadataClient();

        /// <summary>
        /// Gets the FileMetadataByPlanId
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>File Metadata Json Object</returns>    
        // GET api/Plans/PlanById?id=planName
        [Route("PlanById")]
        public IHttpActionResult GetPlanById(string id)
        {
            try
            {
                //this._logger.Info("Calling the FileMetadata method to get all FileMetadata info filtered by category, sub category, plan");

                IFileMetadata fileMetadata = new FileMetadataClient();
                //var getFileMetadataInfo = this.SetGetFileMetadataByPlanMemoryCache(id);
                var getFileMetadataInfo = fileMetadata.GetFileMetadataByPlanAsync(id);
                var fileMetadataInfo = getFileMetadataInfo.Result;

                var categories = from category in fileMetadataInfo
                                 group category by category.CategoryId into categoryGroup
                                 orderby categoryGroup.Key
                                 select categoryGroup;

                var categoryList = new List<Category>();

                foreach (var category in categories)
                {
                    foreach (var categoryItem in category)
                    {
                        var cat = new Category() { Id = categoryItem.CategoryId, Name = this.GetCategoryName(categoryItem.CategoryId) };

                        var subCategories = from subCategory in fileMetadataInfo
                                            where subCategory.CategoryId == categoryItem.CategoryId
                                            group subCategory by subCategory.SubCategoryId into subCategoryGroup
                                            orderby subCategoryGroup.Key
                                            select subCategoryGroup;

                        categoryList.Add(this.GetSubCategoryList(subCategories, categoryItem, fileMetadataInfo, cat));
                        break;
                    }
                }

                var fileMetadataByPlan = new FileMetadataByPlan() { Categories = categoryList };

                if (fileMetadataByPlan.Categories.Count <= 0)
                {
                    return this.BadRequest();
                }

                //this._logger.Info("FileMetadata records have been fetched");
                return this.Ok(fileMetadataByPlan);
            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return StatusCode(HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// The set get categories memory cache.
        /// </summary>
        /// <returns>
        /// The <see cref="Task"/>.
        /// </returns>
        //private Task<FileMetadataDataContract[]> SetGetFileMetadataByPlanMemoryCache(string id)
        //{
        //    string key = "FileMetadataInfoByPlanMemoryKey-Cache";
        //    Task<FileMetadataDataContract[]> getFileMetadataInfo;

        //    if (this._memoryCache != null)
        //    {
        //        if (!this._memoryCache.TryGetValue(key, out getFileMetadataInfo))
        //        {
        //            getFileMetadataInfo = this.FileMetadata.GetFileMetadataByPlanAsync(id);
        //            this._memoryCache.Set(key, getFileMetadataInfo, new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(1)));
        //            this._logger.LogInformation("FileMetadata records have been added in Cache");
        //        }
        //        else
        //        {
        //            getFileMetadataInfo = this._memoryCache.Get(key) as Task<FileMetadataDataContract[]>;
        //            this._logger.LogInformation("FileMetadata records have been retrieved from in Cache");
        //        }
        //    }
        //    else
        //    {
        //        getFileMetadataInfo = this.FileMetadata.GetFileMetadataByPlanAsync(id);
        //    }

        //    return getFileMetadataInfo;
        //}

        /// <summary>
        /// Gets the name of the category.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Category Name</returns>
        public string GetCategoryName(int id)
        {
            try
            {
                var getCategories = fileMetadata.GetCategoriesAsync();
                var categories = getCategories.Result;
                if (!categories.Any())
                {
                    return string.Empty;
                }

                var categoryName = categories.First(a => a.Id == id).Name;
                return categoryName;
            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return ex.Message;
            }
        }

        /// <summary>
        /// Gets the name of the sub category.
        /// </summary>
        /// <param name="categoryId">The category identifier.</param>
        /// <param name="subCategoryId">The sub category identifier.</param>
        /// <returns>SubCategory Name</returns>
        public string GetSubCategoryName(int categoryId, int subCategoryId)
        {
            try
            {
                var getCategories = fileMetadata.GetCategoriesAsync();
                var categories = getCategories.Result;
                if (!categories.Any())
                {
                    return string.Empty;
                }

                var subcatName = categories.First(a => a.Id == categoryId).SubCategories.First(a => a.Id == subCategoryId).Name;

                return subcatName;
            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return ex.Message;
            }
        }

        /// <summary>
        /// Gets the file metadata information.
        /// </summary>
        /// <param name="fileMetadatalist">The filemetadata list.</param>
        /// <returns>File Metadata List</returns>
        public List<FileMetadataList> GetFileMetadataInfo(IEnumerable<FileMetadataDataContract> fileMetadatalist)
        {
            var fileMetadataRecords = new List<FileMetadataList>();

            foreach (var fileMetadata in fileMetadatalist)
            {
                var file = new FileMetadataList()
                {
                    Id = fileMetadata.Id,
                    AccessedOn = fileMetadata.AccessedOn.ToString("MM/dd/yyyy"),
                    ExpirationDate = fileMetadata.ExpirationDate.ToString("MM/dd/yyyy"),
                    FileExtensionId = fileMetadata.FileExtensionId,
                    FileName = fileMetadata.FileName,
                    DisplayName = fileMetadata.DisplayName,
                    PlanName = fileMetadata.PlanName,
                    StatusDate = fileMetadata.StatusDate.ToString("MM/dd/yyyy"),
                    SposUrl = fileMetadata.SposUrl,
                    StatusId = fileMetadata.StatusId,
                    StatusName = fileMetadata.StatusName
                };

                fileMetadataRecords.Add(file);
            }

            return fileMetadataRecords;
        }

        /// <summary>
        /// Gets the sub category list.
        /// </summary>
        /// <param name="subCategories">The sub categories.</param>
        /// <param name="catItem">The category object item.</param>
        /// <param name="fileMetadataInfo">The filemetadata information.</param>
        /// <param name="cat">The category object.</param>
        /// <returns>Category Object</returns>
        public Category GetSubCategoryList(IOrderedEnumerable<IGrouping<int, FileMetadataDataContract>> subCategories, FileMetadataDataContract catItem, FileMetadataDataContract[] fileMetadataInfo, Category cat)
        {
            foreach (var subCategory in subCategories)
            {
                var subCat = new SubCategory();

                foreach (var subCatItem in subCategory)
                {
                    subCat.Id = subCatItem.SubCategoryId;
                    subCat.Name = this.GetSubCategoryName(catItem.CategoryId, subCatItem.SubCategoryId);

                    var fileMetadatalist = from fileMetadata in fileMetadataInfo
                                           where fileMetadata.CategoryId == catItem.CategoryId
                                           where fileMetadata.SubCategoryId == subCatItem.SubCategoryId
                                           select fileMetadata;
                    subCat.FileMetadata.AddRange(this.GetFileMetadataInfo(fileMetadatalist));
                    break;

                }

                cat.SubCategories.Add(subCat);

            }

            return cat;
        }

        /// <summary>
        /// File Metadata By plan Class
        /// </summary>
        public class FileMetadataByPlan
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="FileMetadataByPlan"/> class.
            /// </summary>
            public FileMetadataByPlan()
            {
                this.Categories = new List<Category>();
            }

            /// <summary>
            /// Gets or sets the categories.
            /// </summary>
            /// <value>
            /// The categories.
            /// </value>
            public List<Category> Categories { get; set; }
        }

        /// <summary>
        /// Category Class
        /// </summary>
        public class Category
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="Category"/> class.
            /// </summary>
            public Category()
            {
                this.SubCategories = new List<SubCategory>();
            }

            /// <summary>
            /// Gets or sets the Id.
            /// </summary>
            /// <value>
            /// The Category identifier.
            /// </value>          
            public int Id { get; set; }

            /// <summary>
            /// Gets or sets the Name.
            /// </summary>
            /// <value>
            /// The Category name.
            /// </value>          
            public string Name { get; set; }

            /// <summary>
            /// Gets or sets the List of SubCategories.
            /// </summary>
            /// <value>
            /// List of SubCategories.
            /// </value>           
            public List<SubCategory> SubCategories { get; set; }
        }

        /// <summary>
        /// SubCategory Class
        /// </summary>
        public class SubCategory
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="SubCategory"/> class.
            /// </summary>
            public SubCategory()
            {
                this.FileMetadata = new List<FileMetadataList>();
            }

            /// <summary>
            /// Gets or sets the Id.
            /// </summary>
            /// <value>
            /// The identifier for SubCategory.
            /// </value>        
            public int Id { get; set; }

            /// <summary>
            /// Gets or sets the Name.
            /// </summary>
            /// <value>
            /// The SubCategory Name.
            /// </value>       
            public string Name { get; set; }

            /// <summary>
            /// Gets or sets the file metadata.
            /// </summary>
            /// <value>
            /// The file metadata.
            /// </value>
            public List<FileMetadataList> FileMetadata { get; set; }
        }

        /// <summary>
        /// File MetadataList Class
        /// </summary>
        public class FileMetadataList
        {
            /// <summary>
            /// Gets or sets the accessed on.
            /// </summary>
            /// <value>
            /// The accessed on.
            /// </value>
            public string AccessedOn { get; set; }

            /// <summary>
            /// Gets or sets the expiration date.
            /// </summary>
            /// <value>
            /// The expiration date.
            /// </value>
            public string ExpirationDate { get; set; }

            /// <summary>
            /// Gets or sets the file extension identifier.
            /// </summary>
            /// <value>
            /// The file extension identifier.
            /// </value>
            public int FileExtensionId { get; set; }

            /// <summary>
            /// Gets or sets the name of the file.
            /// </summary>
            /// <value>
            /// The name of the file.
            /// </value>
            public string FileName { get; set; }

            /// <summary>
            /// Gets or sets the Display name.
            /// </summary>
            /// <value>
            /// The status name.
            /// </value>
            public string DisplayName { get; set; }

            /// <summary>
            /// Gets or sets the name of the plan.
            /// </summary>
            /// <value>
            /// The name of the plan.
            /// </value>
            public string PlanName { get; set; }

            /// <summary>
            /// Gets or sets the publication date.
            /// </summary>
            /// <value>
            /// The publication date.
            /// </value>
            public string StatusDate { get; set; }

            /// <summary>
            /// Gets or sets the spos identifier.
            /// </summary>
            /// <value>
            /// The SPOS identifier.
            /// </value>
            public int SposId { get; set; }

            /// Gets or sets the spos url.
            /// </summary>
            /// <value>
            /// The SPOS url.
            /// </value>
            public string SposUrl { get; set; }

            /// <summary>
            /// Gets or sets the status identifier.
            /// </summary>
            /// <value>
            /// The status identifier.
            /// </value>
            public int StatusId { get; set; }

            /// <summary>
            /// Gets or sets the status name.
            /// </summary>
            /// <value>
            /// The status name.
            /// </value>
            public string StatusName { get; set; }

            /// <summary>
            /// Gets or sets the identifier.
            /// </summary>
            /// <value>
            /// The identifier.
            /// </value>           
            public int Id { get; set; }

        }
    }
}
