﻿CREATE TABLE [dbo].[Audit] (
    [Id]             INT        NOT NULL IDENTITY(1, 1),
    [UserId]         VARCHAR(100) NOT NULL,
    [PlanId]         VARCHAR(10) NULL,
    [FileMetadataId] INT        NULL,
    [OperationId]    INT        NOT NULL,
    [Description]    VARCHAR(255)       NOT NULL,
    [CreatedOn]      DATETIME   NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);




