﻿CREATE TABLE [dbo].[AuditOperation]
(
	[Id] INT NOT NULL,
	[Name] VARCHAR(40) NOT NULL, 
    [Description] VARCHAR(255) NULL
)
