﻿CREATE TABLE [dbo].[Category]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [Name] VARCHAR(100) NOT NULL, 
    [Description] VARCHAR(255) NULL, 
    [CreatedBy] VARCHAR(100) NOT NULL, 
    [LastUpdated] DATE NOT NULL, 
    [IsActive] BIT NOT NULL DEFAULT 1
)
