﻿CREATE TABLE [dbo].[FileExtension]
(
	[Id] INT NOT NULL, 
    [Name] VARCHAR(10) NOT NULL, 
    [Description] VARCHAR(255) NULL, 
    CONSTRAINT [PK_FileExtension] PRIMARY KEY ([Id])
)
