﻿CREATE TABLE [dbo].[FileMetadata] (
    [Id]              INT         IDENTITY (1, 1) NOT NULL,
    [PlanName]        VARCHAR(10)  NOT NULL,
    [CategoryId] INT         NOT NULL,
    [SubCategoryId]  INT         NOT NULL,
	[DisplayName]        VARCHAR(255) NOT NULL,
    [FileName]        VARCHAR(255) NOT NULL,
    [FileExtensionId] INT         NOT NULL,
    [SposId]          INT         NOT NULL,
	[IsActive]  BIT      NOT NULL DEFAULT 1,
    [StatusId]        INT         NOT NULL,
	[StatusDate] DATETIME    NULL,
    [ExpirationDate]  DATETIME    NOT NULL,
    [AccessedOn]      DATETIME    NULL,
    [CreatedOn]       DATETIME    NOT NULL,
    [FileSize] INT NULL, 
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_FileMetadata_Category] FOREIGN KEY ([CategoryId]) REFERENCES [dbo].[Category] ([Id]),
    CONSTRAINT [FK_FileMetadata_SubCategory] FOREIGN KEY ([SubCategoryId]) REFERENCES [dbo].[SubCategory] ([Id]),
    CONSTRAINT [FK_FileMetadata_Spos] FOREIGN KEY ([SposId]) REFERENCES [dbo].[Spos] ([Id])
);




