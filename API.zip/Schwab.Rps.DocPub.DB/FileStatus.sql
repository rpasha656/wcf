﻿CREATE TABLE [dbo].[FileStatus]
(
	[Id] INT NOT NULL, 
    [Status] VARCHAR(50) NOT NULL, 
    [Description] VARCHAR(255) NULL, 
    CONSTRAINT [PK_FileStatus] PRIMARY KEY ([Id])
)
